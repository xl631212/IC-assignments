//============================================================================
// Name        : assi5.cpp
// Author      : rh1213
// Version     :
// Copyright   : Your copyright notice
// Description :Assignment 5
//============================================================================
#include<iostream>
#include<fstream>
#include<string>
#include<cstdlib>
#include<math.h>

using namespace std;

typedef int Item;

struct Node {
	Item data;
	Node* next;
};

typedef Node* NodePtr;

NodePtr hdList = NULL;

void read_data_file(NodePtr &hdList, string x);
void BubbleSort(NodePtr &hdList);
void writeintofile(NodePtr &hdList, string x);
void insertItem(NodePtr &hdList, Item data, bool Sort);
void deletedata(NodePtr &hdList, Item data);
void countnumber(NodePtr &hdList, string x);
void minimum(NodePtr &hdList, string x);
void difference(NodePtr &hdList);
int main(int argc, char *argv[]) {

	string filename;
	string temp;
	string x;
	ifstream infile;
	Item newdata;
	bool Sort = false;
	NodePtr hdList = new Node;
	//to open the file in Terminal, we need argument whose length is 2. Other wise, it is false instruction.
	string cmd;
	if (argc != 2) {
		cout << "no command file entered exit." << endl;
		exit(1);
	}

	infile.open(argv[1]);

	if (!infile.is_open()) {
		cout << "can't find" << endl;
		exit(EXIT_FAILURE);

	}

	while (infile >> temp) {
		if (temp == "r") {
			infile >> x;
			read_data_file(hdList, x);
		}
		if (temp == "s") {
			BubbleSort(hdList);
			Sort = true; //I need Sort in insertItem function
		}
		if (temp == "w") {
			writeintofile(hdList, x);
		}
		if (temp == "i") {
			infile >> newdata;
			insertItem(hdList, newdata, Sort);
		}
		if (temp == "d") {
			infile >> newdata;
			deletedata(hdList, newdata);
		}
		if (temp == "e") {
			countnumber(hdList, x);
		}
		if (temp == "m") {
			minimum(hdList, x);
		}
		if (temp == "a") {
			difference(hdList);
		}
	}
	infile.close();

}

void read_data_file(NodePtr &hdList, string x) { //pass by reference so that any change of hdList in this function will update hdList in other places
	ifstream infile1;
	int datainfile;
	string namefile;
	NodePtr newNode = new Node;
	namefile = "data_" + x;
	namefile = namefile + ".txt";
	infile1.open(namefile.c_str());

	if (!infile1.is_open()) {
		exit(EXIT_FAILURE);
	}
	infile1 >> hdList->data; //read the first element that hdList points toward
	hdList->next = NULL;
	while (infile1 >> newNode->data) {
		newNode->next = hdList;
		hdList = newNode;
		newNode = new Node;  //update newNode everytime for next use.
	}
	delete newNode;// delete to reserve space in case for other use.
	infile1.close();

}
void BubbleSort(NodePtr &hdList) {
	int count = 0, number;
	NodePtr start = hdList;
	NodePtr CurrentPtr, LastPtr, temp, SearchPtr;

	while (start != NULL) { //know how many elements in the heap
		count++;
		start = start->next;
	}

	for (number = 0; number < count; ++number) { //so that every time we finish one completed checking ,the last element is set and won't be compared anymore.

		CurrentPtr = LastPtr = hdList; //Initialize CurrentPtr and LastPtr
		SearchPtr = CurrentPtr->next; //SearchPtr is one step advance
		while (CurrentPtr->next != NULL) {
			if (CurrentPtr->data > SearchPtr->data) { //compare CurrentPtr and SearchPtr to see if swap is needed.

				temp = SearchPtr; //swap pointers for CurrentPtr and SearchPtr
				CurrentPtr->next = SearchPtr->next;
				temp->next = CurrentPtr;

				//swapping to preserve the correct positions of pointers.
				if (CurrentPtr == hdList) //this is the case of the first element swapping to preserve the head pointer
					hdList = LastPtr = temp;
				else//normal case
					LastPtr->next = temp;
				CurrentPtr = temp;
			}
			//update pointers
			LastPtr = CurrentPtr;
			CurrentPtr = SearchPtr;
			SearchPtr = SearchPtr->next;
		}
	}
	delete start,CurrentPtr, LastPtr, temp, SearchPtr;
}


void writeintofile(NodePtr &hdList, string x) {
	ofstream fileout;
	string namefile;
	NodePtr SearchNode = hdList;
	namefile = "output_" + x;
	namefile = namefile + ".txt";
	fileout.open(namefile.c_str(), ios::app);// use append instruction so that the file is edited without deleting the old data
	if (!fileout.is_open()) {
		exit(EXIT_FAILURE);
	}

	while (SearchNode != NULL) {
		fileout << SearchNode->data << endl;
		SearchNode = SearchNode->next;
	}
	delete SearchNode;
	fileout.close();
}
void insertItem(NodePtr &hdList, Item data, bool Sort) {  //need Sort because it is easier to deal if the order is not sorted
	bool found = false;
	NodePtr searchPtr, lastPtr, newPtr;

	newPtr = new Node;
	newPtr->data = data;
	newPtr->next = NULL;

	if (hdList == NULL) { //if there is no element in the heap, just insert in as the first element.
		hdList = newPtr;
		return;
	}

	else if (Sort == false && hdList->data >= data) { //we can put the data anywhere in an unsorted heap, here we put it as the first element
		newPtr->next = hdList;
		hdList = newPtr;
	} else if (Sort == true) { //if sort, we need to find the correct place, two pointers are used to compare with data
		found = false;
		searchPtr = hdList;
		lastPtr = hdList;
		while ((searchPtr != NULL) && (!found)) {
			if (searchPtr->data >= data)
				found = true;

			else {
				lastPtr = searchPtr;
				searchPtr = searchPtr->next;

			}

		} //have found, insert the newPtr in the heap
		newPtr->next = searchPtr;
		lastPtr->next = newPtr;

	}
	delete  searchPtr, lastPtr, newPtr;
}

void deletedata(NodePtr &hdList, Item data) {
	NodePtr searchPtr, lastPtr, oldPtr;
	bool found = false;
	if (hdList == NULL) {
		return;
	} else if (hdList->data == data) {
		oldPtr = hdList;
		hdList = hdList->next;
		delete oldPtr;
	}

	else {

		searchPtr = hdList;
		lastPtr = hdList;
		while (searchPtr != NULL && (!found)) {
			searchPtr = searchPtr->next;
			if (searchPtr->data == data) {
				found = true;
				lastPtr->next = searchPtr->next;
				delete searchPtr;
			} else {
				lastPtr = lastPtr->next;
			}

		}

	}
	delete searchPtr, lastPtr, oldPtr;
}

void countnumber(NodePtr &hdList, string x) {
	int count = 0;
	ofstream fileout;
	string namefile;
	namefile = "output_" + x;
	namefile = namefile + ".txt";
	fileout.open(namefile.c_str(), ios::app);

	NodePtr searchPtr;
	searchPtr = hdList;

	if (!fileout.is_open()) {
		exit(EXIT_FAILURE);
	}

	if (searchPtr == NULL) {
	}
	while (searchPtr != NULL) {
		searchPtr = searchPtr->next;
		count++;

	}
	fileout << "Number of elements in the list: " << count << endl;
	delete searchPtr;
	fileout.close();

}

void minimum(NodePtr &hdList, string x) {

	int minimum = 999999;
	ofstream fileout1;
	string namefile;
	NodePtr searchPtr;
	searchPtr = hdList;
	namefile = "output_" + x;
	namefile = namefile + ".txt";
	fileout1.open(namefile.c_str(), ios::app);
	if (!fileout1.is_open()) {
		exit(EXIT_FAILURE);
	}
	if (hdList == NULL) {

		fileout1 << "no heap" << endl;
		return;
	}
	while (searchPtr != NULL) {
		if (searchPtr->data < minimum) {
			minimum = searchPtr->data;
		}
		searchPtr = searchPtr->next;
	}
	delete searchPtr;
	fileout1 << "Minimum value:" << minimum << endl;
}

void difference(NodePtr &hdList) {

	Item data;
	NodePtr searchPtr, lastPtr, newPtr;
	newPtr = new Node;
	searchPtr = hdList->next;
	lastPtr = hdList;

	if (hdList == NULL || searchPtr->next == NULL) {
		return;
	} else {
		while (searchPtr != NULL) {

			if (searchPtr->data - lastPtr->data > 5
					|| searchPtr->data - lastPtr->data < -5) {
				newPtr = new Node;//update every time
				data = round((searchPtr->data + lastPtr->data) / (2.0));
				newPtr->data = data;
				newPtr->next = searchPtr;
				lastPtr->next = newPtr;
				searchPtr = hdList->next;
				lastPtr = hdList;
				continue;// so that we won't escape the first two element for the next loop
			}
			searchPtr = searchPtr->next;
			lastPtr = lastPtr->next;
		}
	}

}

