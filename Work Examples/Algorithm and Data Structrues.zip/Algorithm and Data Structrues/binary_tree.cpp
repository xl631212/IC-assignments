//name : ruiyun He
//email: rh1213@ic.ac.uk
//login name:rh1213

#include <iostream>

using namespace std;

// Declare the data structure
struct CP {
    int id;            // id of the node
    int data;        // data of the node
    CP * left;        // pointer to the left subtree
    CP * right;        // pointer to the right subtree
};

typedef CP * CPPtr;

// Function prototypes

// Generate an instance of the structure
void constructStructure(CPPtr &SP);
int number_of_nodes_func(CPPtr hdTree, int count);
int odd_number_of_nodes_func(CPPtr hdTree, int n);
CPPtr minimum_nodes_func(CPPtr hdTree);
int sum_of_nodes_func(CPPtr hdTree);
int search_id_depth_func(CPPtr hdTree, int id);
int height(CPPtr hdTree);
int check_balance_func(CPPtr hdTree);

int main(int argc, char ** argv) {
    CPPtr hdTree = NULL;
    // Declare a pointer to the head of the tree

    constructStructure(hdTree);
// =================================
    int number_of_nodes = 0, odd_number = 0, sum_of_nodes = 0;// initialization
    CPPtr minimum_nodes = NULL;
    int search_id_depth;
    int BF;
    int id;
    if(hdTree==NULL){
    	cout<<"the tree is empty"<<endl;
    }
    // Construct a tree structure.
    else{
    number_of_nodes = number_of_nodes_func(hdTree, number_of_nodes);

    odd_number = odd_number_of_nodes_func(hdTree, odd_number);

    minimum_nodes = minimum_nodes_func(hdTree);

    sum_of_nodes = sum_of_nodes_func(hdTree);

    cout<<"number_of_nodes"<<number_of_nodes<<endl;

    cout<<"odd_number"<<odd_number<<endl;

    cout<<"minimum_nodes"<<minimum_nodes->data<<endl;

    cout<<"sum_of_nodes"<<sum_of_nodes<<endl;

   // cout << "Enter node  NodeID: " << endl;

 //   cin >> id;
    id=5;
    search_id_depth = search_id_depth_func(hdTree,id);

    cout << "Depth of node(id=" << id << "): " << search_id_depth << endl;

    BF=check_balance_func(hdTree);

    if((BF>1)||(BF<-1)){
    	cout<<"unbalanced tree"<<endl;
   }
    else{
    	cout<<"balanced tree"<<endl;
    }
    }
    // =================================

    // Just to freeze the console window (not always necessary)
    // getchar();

    return 0;
}

// The function generates an instance of the structure (the same as in the description of the assignement document). The SP pointer
// points to the head of the tree

int number_of_nodes_func(CPPtr hdTree, int number_of_nodes) {
    CPPtr searchPtr = NULL;
    searchPtr = new CP;
    searchPtr = hdTree;

    if (searchPtr != NULL) {
        number_of_nodes = number_of_nodes_func(searchPtr->left,
                number_of_nodes);		//recursion always always from the left node first
        number_of_nodes++;				//add one if the node is not null
        number_of_nodes = number_of_nodes_func(searchPtr->right,
                number_of_nodes);		//then search in the right branch
    }
    return number_of_nodes;
}

int odd_number_of_nodes_func(CPPtr hdTree, int n) {
    CPPtr searchPtr = NULL;
    searchPtr = new CP;
    searchPtr = hdTree;
    if (searchPtr != NULL) {
        n = odd_number_of_nodes_func(searchPtr->left, n);
        if (searchPtr->data % 2 != 0) {   //same method as the counting nodes function, but the count only increment when it is odd number
            n++;
        }
        n = odd_number_of_nodes_func(searchPtr->right, n);
    }
    return n;
}

CPPtr minimum_nodes_func(CPPtr hdTree) { //since the tree is ordered, we only look at the most left node
    CPPtr minimumPtr = NULL;
    minimumPtr = new CP;
    minimumPtr = hdTree;

    if (minimumPtr->left != NULL) { //stop looking downward at the most left nodes
        minimumPtr = minimum_nodes_func(minimumPtr->left);
    }
    return minimumPtr;
}

int sum_of_nodes_func(CPPtr hdTree) {
    int sum = 0;
    CPPtr searchPtr = NULL;
    searchPtr = new CP;
    searchPtr = hdTree;
    if (searchPtr != NULL) {
    	sum=searchPtr->data;
        sum = sum + sum_of_nodes_func(searchPtr->left)+ sum_of_nodes_func(searchPtr->right);
    }
    return sum;
}

int search_id_depth_func(CPPtr hdTree,int id){
	int depth = -1; //if there is no node, return depth -1;
	if (hdTree != NULL) { //count the depth only for not empty tree
		if(hdTree -> id == id){
			return depth = 0; //correct node is found, return 0;
		}
		depth = search_id_depth_func(hdTree ->left,id);
	if(depth == -1){//if we have looked into the wrong branch,then depth is -1
		depth =  search_id_depth_func( hdTree ->right,id); //then we need to look into the other branch
	}
	if(depth != -1){// if we have found the correct id then the depth is not -1, no matter we find it in left branch or right branch
		return depth = depth + 1;//add one to be the depth of current node
	    }
	}
	  return depth;

}

int check_balance_func(CPPtr hdTree){
	int BF=0;
	if(hdTree==NULL){
		return BF;
	}
	if(hdTree!=NULL){
	if((BF>1)||(BF<-1))		return BF; //condition if BF is bigger than 1 or BF is smaller than -1
	else BF=height(hdTree->left)-height(hdTree->right);// otherwise, calculate the BF for this mode
	}
	return BF;
}


int height(CPPtr hdTree){
   if(hdTree == NULL){
   return 0;
}
   if(height(hdTree->left)>height(hdTree->right)){
	   return 1+height(hdTree->left);
   }
   else{
	   return 1+height(hdTree->right);
   }//using recursion to find the longest branch
}

void constructStructure(CPPtr &SP) {
    // Declare a structure with 5 nodes

    CPPtr SP0 = NULL;
    CPPtr SP1 = NULL;
    CPPtr SP2 = NULL;
    CPPtr SP3 = NULL;
    CPPtr SP4 = NULL;

    // build the structure tree
    // State 0
   SP0 = new CP;
    SP0->id = 1;
    SP0->data = 10;
    SP0->left = NULL;
    SP0->right = NULL;
    // State 1
    SP1 = new CP;
    SP1->id = 4;
    SP1->data = 5;
    SP1->left = NULL;
    SP1->right = NULL;
    // State 2
    SP2 = new CP;
    SP2->id = 8;
    SP2->data = 3;
    SP2->left = NULL;
    SP2->right = NULL;
    // State 3
    SP3 = new CP;
    SP3->id = 6;
    SP3->data = 7;
    SP3->left = NULL;
    SP3->right = NULL;
    // State 4
    SP4 = new CP;
    SP4->id = 5;
    SP4->data = 10;
    SP4->left = NULL;
    SP4->right = NULL;

    // Make the connections
    SP0->left = SP1;
    SP0->right = SP4;

    SP1->left = SP2;
    SP1->right = SP3;

    // Make the head pointer to point to the head of the tree
 SP = SP0;
}




